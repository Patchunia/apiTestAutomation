/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: DataDrive tests by reading from external CSV
 */

package globalfunctions;
import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ReadCSV {


    private static final String csvFilePath = new File("src\\test\\resources\\testdata\\").getAbsolutePath();
    private String[] line;
    private List<String[]> lines;

    //pass the filename and read from file
    public   List<String[]> callCSV(String fileName)
    {
        CSVReader reader;
        try {

            reader = new CSVReader(new FileReader(csvFilePath + "\\"  + fileName));

            lines = reader.readAll();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return  lines;
    }

    //pass the filename and write to file
    public void WriteToCSV(String csv, String number)
    {
       try {

            CSVWriter writer = new CSVWriter(new FileWriter(csvFilePath + "\\"  + csv));

            String[] items = {number};

            writer.writeNext(items);

            writer.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}

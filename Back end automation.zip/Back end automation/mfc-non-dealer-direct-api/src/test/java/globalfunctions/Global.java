/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Define Global Variables
 */
package globalfunctions;
import net.serenitybdd.rest.SerenityRest;

import java.io.*;
import java.util.List;
import java.util.Properties;

public class Global {

    private Properties prop;
    private InputStream input ;
    public  String jwtToken = "";
    public  String endPoint = "";
    public  String applicationendPoint = "";
    public  String referenceDataendPoint = "";
    public  String dealerdataUrl = "";
    public  String vehicledataUrl = "";
    public  String approveITUrl = "";
    public  int applicationID = 0;
    public  String whoami = "";
    public  int dashboardID = 0;
    public  String sellerwhoami = "";
    public  String sellerCellphone = "";
    public  String proxy = "";
    public  String henToken  = "";
    public  int port = 0;
    List<String[]> lines;
    ReadCSV test;
    int dashID =0;
    String sessionToken = "";
    public  Global()
    {

        prop = new Properties();
        try {
            input = new FileInputStream("target/classes/application.properties");
            prop.load(input);
            approveITUrl = prop.getProperty("approveITUrl");
            applicationendPoint = prop.getProperty("applicationUrl");
            referenceDataendPoint = prop.getProperty("referencedataUrl");
            jwtToken = prop.getProperty("jwt_token");
            dealerdataUrl = prop.getProperty("dealerdataUrl");
            vehicledataUrl = prop.getProperty("vehicledataUrl");
            test = new ReadCSV();
            whoami =prop.getProperty("whoami");
            sellerwhoami =prop.getProperty("sellerwhoami");
            proxy = prop.getProperty("proxy");
            port = Integer.parseInt(prop.getProperty("port"));
            if(port != 0) {
                SerenityRest.proxy(proxy,port);
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
    public int GetDashID()
    {
        lines = test.callCSV("DashboardID.csv");
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            dashID  = Integer.parseInt(lineContents[0]);
        }
        return  dashID;
    }

    public String GetToken()
    {
        lines = test.callCSV("SessionToken.csv");
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            sessionToken  = lineContents[0];
        }
        return  sessionToken;
    }
    public String GetSellerToken()
    {
        lines = test.callCSV("SellerSessionToken.csv");
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            sessionToken  = lineContents[0];
        }
        return  sessionToken;
    }


}



/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Building JSON Objects
 */
package objectTemplate;

import net.thucydides.core.annotations.Step;
import org.json.JSONArray;
import org.json.JSONObject;

public class objectTemplate {

    private  JSONObject jsonDetailObj;
    Object[] dashboards = new Object[0];
    @Step

    public JSONObject AcceptConsentDetails(String dealType,String sourceSystem, String buyerIdentityNumber,
                                           String sellerIdentityNumber, String buyerCellphone,
                                           String sellerCellphone, String submittedDate,
                                           String status, String description,
                                           String foxReference, String currentBuyerState,
                                           String userType, boolean creditConsent,
                                           boolean bankStatmentsConsent, boolean payslipConsent,
                                           boolean documentationUploaded, boolean monthlyExpensesCaptured,
                                           boolean sellerContactCaptured, boolean buyerCreditCheckPassed) {
        jsonDetailObj = new JSONObject()
                .put("dealType", dealType)
                .put("sourceSystem", sourceSystem)
                .put("buyerIdentityNumber", buyerIdentityNumber)
                .put("buyerCellphone", buyerCellphone)
                .put("creditConsent", creditConsent)
                .put("bankStatmentsConsent", bankStatmentsConsent)
                .put("payslipConsent", payslipConsent);

        return  jsonDetailObj;
    }


    public JSONObject PersonalDetails(int AppilicationID, int titleId, String titleCode , String titleName, int maritalStatusId ,
                                      String maritalStatusCode, String maritalStatusName, int birthCountryId,
                                      String birthCountryCode,String birthCountryName, int nationalityCountryId
                                        ,String nationalityCountryCode , String nationalityCountryName,
                                      int ethnicGroupId, String ethnicGroupCode,String ethnicGroupName,
                                      String lastName, String firstName, String initials, String identityNumber,
                                      String cellphone , String homePhoneNumber, String  workPhoneNumber, String email,
                                      boolean hasMultiNationality, boolean hasForeignTaxObligation ) {

        jsonDetailObj = new JSONObject()
                .put("applicationId", AppilicationID)
                .put("viewingState", "Buyer")
                .put("Buyer", new JSONObject()
                                .put("titleId", titleId)
                                .put("titleCode", titleCode)
                                .put("titleName", titleName)
                                .put("maritalStatusId", maritalStatusId)
                                .put("maritalStatusCode", maritalStatusCode)
                                .put("maritalStatusName", maritalStatusName)
                                .put("birthCountryId", birthCountryId)
                                .put("birthCountryCode", birthCountryCode)
                                .put("birthCountryName", birthCountryName)
                                .put("nationalityCountryId", nationalityCountryId)
                                .put("nationalityCountryCode", nationalityCountryCode)
                                .put("nationalityCountryName", nationalityCountryName)
                                .put("ethnicGroupId", ethnicGroupId)
                                .put("ethnicGroupCode", ethnicGroupCode)
                                .put("ethnicGroupName", ethnicGroupName)
                                .put("lastName", lastName)
                                .put("firstName", firstName)
                                .put("initials", initials)
                                .put("identityNumber", identityNumber)
                                .put("cellphone", cellphone)
                                .put("homePhoneNumber", homePhoneNumber)
                                .put("workPhoneNumber", workPhoneNumber)
                                .put("email", email)
                                .put("hasMultiNationality", hasMultiNationality)
                                .put("hasForeignTaxObligation", hasForeignTaxObligation)

                        );
        return  jsonDetailObj;

    }


    public JSONObject MonthlyExpenses(int ApplicationID,int netSalary,int homeLoansOrRent,
                                      int utilities, int foodAndHousehold,int transportation,
                                      int policiesAndInsurance,int clothing,int entertainment,
                                      int education,int savings, int phone,boolean hasCreditCardPayments,
                                      int creditCard, boolean hasAccountPayments,int account, boolean hasLoanPayments,
                                      int loan,boolean hasOtherPayments, int other, int totalExpenses, int remainingSurplus,
                                      int maxMotorPayments, int vehicleCashPrice
                                      ) {

        jsonDetailObj = new JSONObject()
                         .put("applicationId", ApplicationID)
                        .put("viewingState", "monthlyExpense")
                        .put("monthlyExpense", new JSONObject()
                                .put("netSalary", netSalary)
                                .put("homeLoansOrRent", homeLoansOrRent)
                                .put("utilities", utilities)
                                .put("foodAndHousehold", foodAndHousehold)
                                .put("transportation", transportation)
                                .put("policiesAndInsurance", policiesAndInsurance)
                                .put("clothing", clothing)
                                .put("entertainment", entertainment)
                                .put("education", education)
                                .put("entertainment", entertainment)
                                .put("education", education)
                                .put("savings", savings)
                                .put("phone", phone)
                                .put("hasCreditCardPayments", hasCreditCardPayments)
                                .put("creditCard", creditCard)
                                .put("hasAccountPayments", hasAccountPayments)
                                .put("account", account)
                                .put("hasLoanPayments", hasLoanPayments)
                                .put("loan", loan)
                                .put("hasOtherPayments", hasOtherPayments)
                                .put("other", other)
                                .put("totalExpenses", totalExpenses)
                                .put("remainingSurplus", remainingSurplus)
                                .put("maxMotorPayments", maxMotorPayments)
                                .put("vehicleCashPrice", vehicleCashPrice)
                        );
        return  jsonDetailObj;

    }

    public JSONObject AddressDetails(int ApplicationID, int residentialStatusId,
                                     String residentialStatusCode ,String residentialStatusName,
                                     String address1,String address2,
                                     String suburb, String city,String postCode,String residentSince,
                                     boolean receiveMailAtAddress, String postalAddress1, String postalAddress2,
                                     String postalSuburb, String postalCity, String postalPostCode)
    {

                jsonDetailObj = new JSONObject()
                        .put("applicationId", ApplicationID)
                        .put("viewingState", "address")
                                .put("address", new JSONObject()
                                        .put("residentialStatusId", residentialStatusId)
                                        .put("residentialStatusCode", residentialStatusCode)
                                        .put("residentialStatusName", residentialStatusName)
                                        .put("address1", address1)
                                        .put("address2", address2)
                                        .put("suburb", suburb)
                                        .put("city", city)
                                        .put("postCode", postCode)
                                        .put("residentSince", residentSince)
                                        .put("receiveMailAtAddress", receiveMailAtAddress)
                                        .put("postalAddress1", postalAddress1)
                                        .put("postalAddress2", postalAddress2)
                                        .put("postalSuburb", postalSuburb)
                                        .put("postalCity", postalCity)
                                        .put("postalPostCode", postalPostCode)
                                );
        return jsonDetailObj;
    }


    public JSONObject EmploymentDetails(int ApplicationID, int employmentTypeId,
                                        String employmentTypeCode, String employmentTypeName,
                                        String occupationTypeId, String occupationTypeCode,
                                        String occupationTypeName, String industryTypeId,
                                        String employer, String employmentStartDate)
    {
        jsonDetailObj = new JSONObject()
                .put("applicationId", ApplicationID)
                .put("viewingState", "employment")
                .put("employment", new JSONObject()
                        .put("employmentTypeId",employmentTypeId)
                        .put("employmentTypeCode",employmentTypeCode)
                        .put("employmentTypeName", employmentTypeName)
                        .put("occupationTypeId",occupationTypeId)
                        .put("occupationTypeCode",occupationTypeCode)
                        .put("occupationTypeName",occupationTypeName)
                        .put("industryTypeId",industryTypeId)
                        .put("employer",employer)
                        .put("employmentStartDate",employmentStartDate));
        return jsonDetailObj;


    }
    public JSONObject BankingDetails(int AppilicationID,
                                     int BankID ,String BankCode, String BankName,
                                     int AccountTypeId,String AccountTypeCode,String AccountTypeName,
                                     String AccountNumber,String BranchCode)
    {

        jsonDetailObj = new JSONObject()
                .put("applicationId", AppilicationID)
                .put("viewingState", "Banking")
                        .put("banking", new JSONObject()
                                .put("bankId", BankID)
                                .put("bankCode",BankCode)
                                .put("bankName",BankName)
                                .put("accountTypeId",AccountTypeId)
                                .put("accountTypeCode",AccountTypeCode)
                                .put("accountTypeName",AccountTypeName)
                                .put("accountNumber",AccountNumber)
                                .put("branchCode",BranchCode));
        return  jsonDetailObj;

    }
    public JSONObject PersonalIncomeDetails(int ApplicationId, int netSalary,int grossSalary,
                                            int totalExpenses)
    {
        jsonDetailObj = new JSONObject()
                .put("applicationId", ApplicationId)
                .put("viewingState",  "income")
                        .put("income", new JSONObject()
                                .put("netSalary", netSalary)
                                .put("grossSalary",grossSalary)
                                .put("totalExpenses",totalExpenses));
        return  jsonDetailObj;
    }
    public JSONObject VehicleMakeAndModelDetails(String Make, String Year, String VehType)
    {
        jsonDetailObj =  new JSONObject()
                .put("Make",Make)
                .put("CurrentYear",Year)
                .put("VehType",VehType);
        return  jsonDetailObj;
    }

    public JSONObject ApproveITDetails(String identityNumber, String cellphone,String firstName,
                                       String lastName, String verificationId, String otp,
                                       String reference,String type)
    {
        jsonDetailObj =  new JSONObject()
                .put("identityNumber",identityNumber)
                .put("cellphone",cellphone)
                .put("firstName",firstName)
                .put("lastName",lastName)
                .put("verificationId",verificationId)
                .put("otp",otp)
                .put("reference",reference)
                .put("type",type);
        return  jsonDetailObj;

    }
    public JSONObject SellerApproveITDetails(String identityNumber, String cellphone,String firstName,
                                       String lastName, String verificationId, String otp,
                                       String reference,String type)
    {
        jsonDetailObj =  new JSONObject()
                .put("identityNumber",identityNumber)
                .put("cellphone",cellphone)
                //.put("firstName",firstName)
                //.put("lastName",lastName)
                //.put("verificationId",verificationId)
                .put("allowCheck",true)
                .put("type","Seller")
                .put("reference",reference);
        return  jsonDetailObj;

    }


    public JSONObject CitiesbyregionsDetails(String City)
    {
        jsonDetailObj =  new JSONObject()
                .put("Region",City);
        return  jsonDetailObj;

    }
    public JSONObject DealersbyCityDetails(String City)
    {
        jsonDetailObj =  new JSONObject()
                .put("City",City);
        return  jsonDetailObj;

    }
    public JSONObject DealersbyregionDetails(String region)
    {
        jsonDetailObj =  new JSONObject()
                .put("Region",region);
        return  jsonDetailObj;

    }
    public JSONObject SubmissionToFoxDetails(String dashboardId, String foxReference)
    {
        jsonDetailObj =  new JSONObject()
                .put("dashboardId",dashboardId)
                .put("foxReference",foxReference);
        return  jsonDetailObj;

    }
    public JSONObject SellerContact(int ApplicationID,String identityNumber,String firstName,String lastName
            ,String cellphone,String email,String address1,String address2,String suburb,String city
            ,String postCode,String titleName)
    {

        jsonDetailObj = new JSONObject()
                .put("applicationId",ApplicationID)
                .put("viewingState", "sellerContact")
                        .put("sellerContact", new JSONObject()
                                        .put("identityNumber",identityNumber)
                                        .put("firstName",firstName)
                                        .put("lastName", lastName)
                                        .put("cellphone",cellphone)
                                        .put("email",email)
                                        .put("address1",address1)
                                        .put("address2",address2)
                                        .put("suburb",suburb)
                                        .put("city",city)
                                        .put("postCode",postCode)
                                        .put("titleName",titleName)
                                );
        return  jsonDetailObj;

    }
    public JSONObject BuyerDocuments(int ApplicationID,int documentTypeId,String documentTypeCode,String documentTypeName
            ,String fileFormat,String fileName,int fileSize,String fileContent) {

        jsonDetailObj = new JSONObject()
                .put("applicationId", ApplicationID)
                .put("viewingState", "buyerDocuments")
                .put("buyerDocuments", new JSONArray().put(new JSONObject()
                        .put("applicationId", ApplicationID)
                        .put("documentTypeId", documentTypeId)
                        .put("documentTypeCode", documentTypeCode)
                        .put("documentTypeName", documentTypeName)
                        .put("fileFormat", fileFormat)
                        .put("fileName", fileName)
                        .put("fileSize", fileSize)
                        .put("fileContent", fileContent)
                ));
        return  jsonDetailObj;
    }
    public JSONObject SellerDocuments(int ApplicationID,int documentTypeId,String documentTypeCode,String documentTypeName
            ,String fileFormat,String fileName,int fileSize,String fileContent) {

        jsonDetailObj = new JSONObject()
                .put("applicationId", ApplicationID)
                .put("viewingState", "sellerDocuments")
                .put("sellerDocuments", new JSONArray().put(new JSONObject()
                        .put("applicationId", ApplicationID)
                        .put("documentTypeId", documentTypeId)
                        .put("documentTypeCode", documentTypeCode)
                        .put("documentTypeName", documentTypeName)
                        .put("fileFormat", fileFormat)
                        .put("fileName", fileName)
                        .put("fileSize", fileSize)
                        .put("fileContent", fileContent)
                ));
        return  jsonDetailObj;
    }
    public JSONObject DealerObject(String dealerName) {
        jsonDetailObj =  new JSONObject()
                .put("Name", dealerName);
        return  jsonDetailObj;
    }
    public JSONObject SellerPersonalDetail(int ApplicationID,String identityNumber, String firstName,
                                   String lastName,String cellphone, String email ,
                                   String address1,String address2, String suburb,
                                   String city,String postCode, String titleName) {

        jsonDetailObj = new JSONObject()
                .put("applicationId", ApplicationID)
                .put("viewingState", "sellerDetail")
                .put("sellerDetail", new JSONObject()
                        .put("identityNumber",identityNumber)
                        .put("firstName","FredSeller")
                        .put("lastName","FlintstoneSeller")
                        .put("cellphone","0836380859")
                        .put("email","henryo@mfc.co.za")
                        .put("address1","24 Achter Road")
                        .put("address2","222")
                        .put("suburb","Alberton")
                        .put("city","Johannesburg")
                        .put("postCode","1234")
                );

        return  jsonDetailObj;
    }

    public JSONObject SellerBankingDetail(int ApplicationID,String identityNumber, String firstName,
                                   String lastName,String cellphone, String email ,
                                   String address1,String address2, String suburb,
                                   String city) {

        jsonDetailObj = new JSONObject()
                .put("applicationId", ApplicationID)
                .put("viewingState", "sellerBanking")
                .put("sellerBanking", new JSONObject()
                        .put("bankId", 1)
                        .put("accountTypeId",2)
                        .put("accountHolder","Bob")
                        .put("accountNumber","77665544")
                        .put("branchCode","333"));
        return  jsonDetailObj;

    }
    public JSONObject FoxSecondSubmit(int ApplicationID) {

        jsonDetailObj = new JSONObject()
                .put("applicationId", ApplicationID)
                .put("viewingState", "Status");
        return  jsonDetailObj;

    }

    public JSONObject SellerVehicleResult(int ApplicationID) {

        jsonDetailObj = new JSONObject()
                .put("applicationId", ApplicationID)
                .put("viewingState", "SellerVehicleResult");
        return  jsonDetailObj;

    }

    public JSONObject VehicleDetails(int ApplicationID, int vehicleTypeId, String vehicleTypeCode,
                                     String vehicleTypeName, String dealerCode, String dealer, boolean isNew,
                                     String make, String model , String mmCode, int year, int purchasePrice,
                                     int interestRate, boolean hasDeposit, int deposit,
                                     int loanAmount, boolean hasBalloon, int balloonPercentage,
                                     String firstInstalmentDate, int loanPeriod, int estimatedMonthlyInstalments,
                                     String vinNumber, String rejectionReason, boolean verified
                                    )
    {

        jsonDetailObj = new JSONObject()
                .put("applicationId",ApplicationID)
                .put("viewingState","Vehicle" )
                        .put("vehicle", new JSONObject()
                                        .put("vehicleTypeId", vehicleTypeId)
                                        .put("vehicleTypeCode", vehicleTypeCode)
                                        .put("vehicleTypeName",vehicleTypeName)
                                        .put("dealerCode",dealerCode)
                                        .put("dealer",dealer)
                                        .put("isNew",isNew)
                                        .put("make",make)
                                        .put("model",model)
                                        .put("mmCode", mmCode)
                                        .put("year", year)
                                        .put("purchasePrice", purchasePrice)
                                        .put("interestRate", interestRate)
                                        .put("hasDeposit", hasDeposit)
                                        .put( "deposit", deposit)
                                        .put("loanAmount", loanAmount)
                                        .put("hasBalloon", hasBalloon)
                                        .put("balloonPercentage", balloonPercentage)
                                        .put("firstInstalmentDate", firstInstalmentDate)
                                        .put("estimatedMonthlyInstalments", estimatedMonthlyInstalments)
                                        .put( "vinNumber", vinNumber)
                                        .put("rejectionReason", rejectionReason)
                                        .put("verified", verified));
        return  jsonDetailObj;

    }


    public JSONObject VehicleSellerDetails(int ApplicationID, int vehicleTypeId, String vehicleTypeCode,
                                     String vehicleTypeName, String dealerCode, String dealer, boolean isNew,
                                     String make, String model , String mmCode, int year, int purchasePrice,
                                     int interestRate, boolean hasDeposit, int deposit,
                                     int loanAmount, boolean hasBalloon, int balloonPercentage,
                                     String firstInstalmentDate, int loanPeriod, int estimatedMonthlyInstalments,
                                     String vinNumber, String rejectionReason, boolean verified
    )
    {

        jsonDetailObj = new JSONObject()
                .put("applicationId",ApplicationID)
                .put("viewingState","sellerVehicle" )
                .put("sellerVehicle", new JSONObject()
                        .put( "vinNumber", vinNumber)
                        .put("offerAccepted", true));
        return  jsonDetailObj;

    }

}

/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Sends Application creation requests
 */
package services;
import globalfunctions.Global;
import globalfunctions.ReadCSV;
import objectTemplate.objectTemplate;
import io.restassured.response.Response;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.runner.RunWith;

import static org.hamcrest.Matchers.*;
@RunWith(SerenityRunner.class)
public class CreateRecordAPITests {
    private Response response;
    private objectTemplate objectDetails;
    private Global globalvariables;
    private ReadCSV writeToCSV;
    String dashboardID = "";
    public CreateRecordAPITests() {
        objectDetails = new objectTemplate();
        globalvariables = new Global();
        writeToCSV = new ReadCSV();
    }

    @Step
    public void callCreateRecordAPI(JSONObject anyobject) {

        //SerenityRest.proxy("172.17.2.12 ", 80);
        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .body(anyobject.toString())
                .contentType("application/json")
                .header("Authorization", "Bearer " + globalvariables.GetToken() )
                .header( "x-nedbank-whoami" ,  globalvariables.GetToken())
                .header( "x-nedbank-utype" , "buyer")
                .when()
                .post(globalvariables.applicationendPoint );
    }

    @Step
    public void callCreateRecordAPISeller(JSONObject someobject) {

        //SerenityRest.proxy("172.17.2.12 ", 80);
        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .body(someobject.toString())
                .contentType("application/json")
                .header("Authorization", "Bearer " + globalvariables.GetSellerToken())
                //.header( "x-nedbank-whoami" , globalvariables.GetSellerToken())
                .header( "x-nedbank-utype" , "seller")
                .when()
                .post(globalvariables.applicationendPoint);
    }
    @Step
    public void callAcceptConsentAPI(JSONObject anyobject) {

        //SerenityRest.proxy("172.17.2.12 ", 80);
        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .body(anyobject.toString())
                .contentType("application/json")
                .header("Authorization", "Bearer " + globalvariables.jwtToken )
                .header( "x-nedbank-whoami" ,globalvariables.GetToken())
                .header( " x-nedbank-utype" , "buyer")
                .when()
                .put(globalvariables.applicationendPoint);
    }

    @Step
    public void callUploadDoc(JSONArray anyobject) {
        //SerenityRest.proxy("https://servicesecuritygateway-dev.africa.nedcor.net" , 7804);
        SerenityRest.reset();
        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .body(anyobject.toString())
                .contentType("application/json")
                .header("Authorization", "Bearer " + globalvariables.jwtToken)
                .header( "whoami" , "7109290834086")
                .when()
                .post("https://servicesecuritygateway-dev.africa.nedcor.net:7804/mfcapi/application/UploadDoc");
    }

    public void callSubmitToFoxAPI(JSONObject anyobject) {
        response = SerenityRest
                .given().relaxedHTTPSValidation()
                .body(anyobject.toString())
                .contentType("application/json")
                .header("Authorization", "Bearer " + globalvariables.jwtToken)
                .header( "whoami" , "7109290834086")
                .when()
                .post(globalvariables.applicationendPoint + "/SubmitToFox");
    }
    @Step
    public void saveSubmissionToFox(String dashboardId, String foxReference) {

       // callCreateRecordAPI(objectDetails.SubmissionToFoxDetails(dashboardId,foxReference));
        callSubmitToFoxAPI(objectDetails.SubmissionToFoxDetails(dashboardId,foxReference));
    }
    @Step
    public void saveBankingDetails(int AppilicationID,
                                   int BankID ,String BankCode, String BankName,
                                   int AccountTypeId,String AccountTypeCode,String AccountTypeName,
                                   String AccountNumber,String BranchCode) {

        callCreateRecordAPI(objectDetails.BankingDetails(AppilicationID,BankID,BankCode,BankName,AccountTypeId,
                AccountTypeCode,AccountTypeName,AccountNumber,BranchCode));
    }
    @Step
    public void saveSellerDocuments(int ApplicationID,int documentTypeId,String documentTypeCode,String documentTypeName
            ,String fileFormat,String fileName,int fileSize,String fileContent) {

        callCreateRecordAPISeller(objectDetails.SellerDocuments(ApplicationID,documentTypeId,documentTypeCode,documentTypeName,
               fileFormat,fileName,fileSize,fileContent));
    }
    @Step
    public void saveBuyerDocuments(int ApplicationID,int documentTypeId,String documentTypeCode,String documentTypeName
            ,String fileFormat,String fileName,int fileSize,String fileContent) {

       callCreateRecordAPI(objectDetails.BuyerDocuments(ApplicationID,documentTypeId,documentTypeCode,
               documentTypeName,fileFormat,fileName,fileSize,fileContent));
    }
    @Step
    public void saveFoxSecondSubmit(int ApplicationID) {

        callCreateRecordAPI(objectDetails.FoxSecondSubmit(ApplicationID));
    }

    @Step
    public void savePersonalIncome(int IDNumber, int EarningBeforeDeduction, int EarningAfterDeduction, int MonthlyExpenses) {

        callCreateRecordAPI(objectDetails.PersonalIncomeDetails(IDNumber, EarningBeforeDeduction, EarningAfterDeduction, MonthlyExpenses));

    }
    public void saveMonthlyExpenses(int ApplicationID,int netSalary,int homeLoansOrRent,
                                    int utilities, int foodAndHousehold,int transportation,
                                    int policiesAndInsurance,int clothing,int entertainment,
                                    int education,int savings, int phone,boolean hasCreditCardPayments,
                                    int creditCard, boolean hasAccountPayments,int account, boolean hasLoanPayments,
                                    int loan,boolean hasOtherPayments, int other, int totalExpenses, int remainingSurplus,
                                    int maxMotorPayments, int vehicleCashPrice) {

       callCreateRecordAPI(objectDetails.MonthlyExpenses(ApplicationID,netSalary,homeLoansOrRent,utilities,foodAndHousehold,transportation,
               policiesAndInsurance,clothing,entertainment,education,savings,phone,hasCreditCardPayments,creditCard,hasAccountPayments,account,
               hasLoanPayments,loan,hasOtherPayments,other,totalExpenses,remainingSurplus,maxMotorPayments,vehicleCashPrice));

    }

    @Step
    public void saveFinanceAmount(int IDNumber, String PurchasePrice, int Deposit, int BalloonPayment,
                                  boolean balloonPaymentOption, String firstPayment, int term,
                                  int interestRate, int estimatedMonthlyInstalment, boolean dealerType) {

        /*callCreateRecordAPI(objectDetails.VehicleInstallmentDetails(IDNumber, PurchasePrice, Deposit, BalloonPayment,
                balloonPaymentOption, firstPayment, term, interestRate, estimatedMonthlyInstalment, dealerType));*/
    }


    @Step
    public void saveSellerPersonalDetails(int ApplicationID,String identityNumber, String firstName,
                                  String lastName,String cellphone, String email ,
                                  String address1,String address2, String suburb,
                                  String city,String postCode, String titleName){

        callCreateRecordAPISeller(objectDetails.SellerPersonalDetail(ApplicationID,identityNumber,firstName,lastName,cellphone,email,
                address1,address2,suburb,city,postCode,titleName));
    }
    @Step
    public void saveSellerBankingDetails(int ApplicationID,String identityNumber, String firstName,
                                         String lastName,String cellphone, String email ,
                                         String address1,String address2, String suburb,
                                         String city){

        callCreateRecordAPISeller(objectDetails.SellerBankingDetail(ApplicationID,identityNumber,firstName,lastName,
                cellphone,email,address1,address2,suburb,city));
    }
    @Step
    public void saveSellerContact(int ApplicationID,String identityNumber,String firstName,String lastName
            ,String cellphone,String email,String address1,String address2,String suburb,String city
            ,String postCode,String titleName){

        callCreateRecordAPI(objectDetails.SellerContact(ApplicationID,identityNumber,firstName,lastName,
                cellphone,email,address1,address2,suburb,city,postCode,titleName));
    }
    @Step
    public void saveSellerVehicleResult(int ApplicationID){

        callCreateRecordAPISeller(objectDetails.SellerVehicleResult(ApplicationID));
    }
    @Step
    public void saveVehicleDetails(int ApplicationID, int vehicleTypeId, String vehicleTypeCode,
                                   String vehicleTypeName, String dealerCode, String dealer, boolean isNew,
                                   String make, String model , String mmCode, int year, int purchasePrice,
                                   int interestRate, boolean hasDeposit, int deposit,
                                   int loanAmount, boolean hasBalloon, int balloonPercentage,
                                   String firstInstalmentDate, int loanPeriod, int estimatedMonthlyInstalments,
                                   String vinNumber, String rejectionReason, boolean verified){

        callCreateRecordAPI(objectDetails.VehicleDetails(ApplicationID,vehicleTypeId,vehicleTypeCode,vehicleTypeName,
                dealerCode,dealer,isNew,make,model,mmCode,year,purchasePrice,interestRate,hasDeposit,deposit,
                loanAmount,hasBalloon,balloonPercentage,firstInstalmentDate,loanPeriod,estimatedMonthlyInstalments,vinNumber,
                rejectionReason,verified));
    }
    @Step
    public void saveSellerVehicleDetails(int ApplicationID, int vehicleTypeId, String vehicleTypeCode,
                                   String vehicleTypeName, String dealerCode, String dealer, boolean isNew,
                                   String make, String model , String mmCode, int year, int purchasePrice,
                                   int interestRate, boolean hasDeposit, int deposit,
                                   int loanAmount, boolean hasBalloon, int balloonPercentage,
                                   String firstInstalmentDate, int loanPeriod, int estimatedMonthlyInstalments,
                                   String vinNumber, String rejectionReason, boolean verified){

        callCreateRecordAPISeller(objectDetails.VehicleSellerDetails(ApplicationID,vehicleTypeId,vehicleTypeCode,vehicleTypeName,
                dealerCode,dealer,isNew,make,model,mmCode,year,purchasePrice,interestRate,hasDeposit,deposit,
                loanAmount,hasBalloon,balloonPercentage,firstInstalmentDate,loanPeriod,estimatedMonthlyInstalments,vinNumber,
                rejectionReason,verified));
    }
    @Step
    public void savePersonalDetails(int AppilicationID, int titleId, String titleCode , String titleName, int maritalStatusId ,
                                    String maritalStatusCode, String maritalStatusName, int birthCountryId,
                                    String birthCountryCode,String birthCountryName, int nationalityCountryId
            ,String nationalityCountryCode , String nationalityCountryName,
                                    int ethnicGroupId, String ethnicGroupCode,String ethnicGroupName,
                                    String lastName, String firstName, String initials, String identityNumber,
                                    String cellphone , String homePhoneNumber, String  workPhoneNumber, String email,
                                    boolean hasMultiNationality, boolean hasForeignTaxObligation)
    {

        callCreateRecordAPI( objectDetails.PersonalDetails(AppilicationID,titleId,titleCode,titleName,maritalStatusId,
                maritalStatusCode,maritalStatusName,birthCountryId,birthCountryCode,birthCountryName,nationalityCountryId,
                nationalityCountryCode,nationalityCountryName,ethnicGroupId,ethnicGroupCode, ethnicGroupName,lastName,firstName,initials,
                identityNumber,cellphone,homePhoneNumber,workPhoneNumber,email,hasMultiNationality,hasForeignTaxObligation));

    }

    @Step
    public void saveResidentialAddress(int ApplicationID, int residentialStatusId,
                                       String residentialStatusCode ,String residentialStatusName,
                                       String address1,String address2,
                                       String suburb, String city,String postCode,String residentSince,
                                       boolean receiveMailAtAddress, String postalAddress1, String postalAddress2,
                                       String postalSuburb, String postalCity, String postalPostCode ){

        callCreateRecordAPI(objectDetails.AddressDetails(ApplicationID,residentialStatusId,residentialStatusCode,residentialStatusName,
                address1,address2,suburb,city,postCode,residentSince,receiveMailAtAddress,postalAddress1,postalAddress2,
                postalSuburb,postalCity,postalPostCode));

    }
    @Step
    public void saveAcceptConsentDetails(String dealType,String sourceSystem, String buyerIdentityNumber,
                                      String sellerIdentityNumber, String buyerCellphone,
                                      String sellerCellphone, String submittedDate,
                                      String status, String description,
                                      String foxReference, String currentBuyerState,
                                      String userType, boolean creditConsent,
                                      boolean bankStatmentsConsent, boolean payslipConsent,
                                      boolean documentationUploaded, boolean monthlyExpensesCaptured,
                                      boolean sellerContactCaptured, boolean buyerCreditCheckPassed){

        //this opertaion is a PUT to start up an application
        callAcceptConsentAPI(objectDetails.AcceptConsentDetails(
                dealType,sourceSystem, buyerIdentityNumber, sellerIdentityNumber,buyerCellphone,sellerCellphone,
                submittedDate,status,description,foxReference,currentBuyerState,userType,creditConsent,bankStatmentsConsent,
                payslipConsent,documentationUploaded,monthlyExpensesCaptured,sellerContactCaptured,buyerCreditCheckPassed));

    }
    @Step
    public void saveEmploymentdetails(int ApplicationID, int employmentTypeId,
                                      String employmentTypeCode, String employmentTypeName,
                                      String occupationTypeId, String occupationTypeCode,
                                      String occupationTypeName, String industryTypeId,
                                      String employer, String employmentStartDate){

        callCreateRecordAPI( objectDetails.EmploymentDetails(ApplicationID,employmentTypeId,employmentTypeCode,employmentTypeName,
                occupationTypeId,occupationTypeCode,occupationTypeName,industryTypeId, employer,employmentStartDate));

    }
    @Step
    public  void saveInstallmentDetails(int  IDNumber, String PurchasePrice,int Deposit,int BalloonPayment,
                                        boolean balloonPaymentOption,String firstPayment, int term,
                                        int interestRate,int estimatedMonthlyInstalment, boolean dealerType)
    {
       /* callCreateRecordAPI( objectDetails.VehicleInstallmentDetails(IDNumber,
                PurchasePrice,Deposit,BalloonPayment,balloonPaymentOption, firstPayment,  term,
                 interestRate, estimatedMonthlyInstalment,  dealerType));*/
    }

    @Step
    public void shouldGet200Response(String value){

        response.then().body("metaData.name" , equalTo(value));
    }
    @Step
    public void validateDocUpload(String result)
    {
        response.then().body("result.ResultCode" , equalTo(result));
    }

    @Step
    public void saveDashboardID()
    {
        dashboardID = response.then().extract().path("data.id").toString();
        writeToCSV.WriteToCSV("DashboardiD.csv", dashboardID);

    }
}

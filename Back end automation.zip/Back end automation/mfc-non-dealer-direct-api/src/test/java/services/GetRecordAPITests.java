/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Sends Application retrieving requests
 */
package services;
import globalfunctions.Global;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static org.hamcrest.Matchers.*;

public class GetRecordAPITests {
    private Response response;
    private  Global globalVariables;

    public GetRecordAPITests()
    {
        globalVariables = new Global();
    }

    public Response callGetAPI(String state) {
        response = SerenityRest.given().relaxedHTTPSValidation().
                header("Authorization", "Bearer "+ globalVariables.GetToken())
                //.header( "x-nedbank-whoami" ,  globalVariables.GetToken())
                //.header( "x-nedbank-utype" , "buyer")
                .when()
                .get( globalVariables.applicationendPoint + "/" + globalVariables.GetDashID() + "/states/" + state);
        return response;
    }

    public Response callGetAPISeller(String state) {
        response = SerenityRest.given().relaxedHTTPSValidation().
                header("Authorization", "Bearer "+ globalVariables.GetSellerToken())
                //.header( "x-nedbank-whoami" , globalVariables.GetSellerToken())
                //.header( "x-nedbank-utype" , "seller")
                .when()
                .get( globalVariables.applicationendPoint + "/" + globalVariables.GetDashID() + "/states/" + state);
        return response;
    }

    public Response callGetApplication() {
        response = SerenityRest.given().relaxedHTTPSValidation().
                header("Authorization", "Bearer "+ globalVariables.GetToken())
                //.header( "x-nedbank-whoami" , globalVariables.GetToken())
                //.header( "x-nedbank-utype" , "buyer")
                .header( "applicationid" , globalVariables.GetDashID())
                .when()
                .get( globalVariables.applicationendPoint + "/" +  globalVariables.GetDashID());
        return response;
    }

    public Response callGetClientApplication() {
        response = SerenityRest.given().relaxedHTTPSValidation().
                header("Authorization", "Bearer "+ globalVariables.GetToken())
                .when()
                .get( globalVariables.approveITUrl  + "clientdetails" + "/"+  globalVariables.whoami);
        return response;
    }
    public  String getFoxRef()
    {
       return response.then().extract().path("data.foxReference");
    }

    @Step
    public void validateResponse(String result)
    {
       response.then().body("metaData.name", equalTo(result));
    }


}

/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Sends Application deletion requests
 */
package services;
import globalfunctions.Global;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static org.hamcrest.Matchers.equalTo;

public class DeleteRecordAPITests {
    private Response response;
    private  Global globalVariables;

    public DeleteRecordAPITests()
    {
        globalVariables = new Global();
    }


    public Response callDeleteApplication() {
        response = SerenityRest.given().relaxedHTTPSValidation().
                header("Authorization", "Bearer "+ globalVariables.jwtToken)
                .header( "x-nedbank-whoami" , globalVariables.whoami)
                .header( "x-nedbank-utype" , "buyer")
                .header( "applicationid" , globalVariables.GetDashID())
                .when()
                .delete( globalVariables.applicationendPoint + "/" +  globalVariables.GetDashID());
        return response;
    }

    @Step
    public void validateResponse(String result)
    {
       response.then().body("metaData.name", equalTo(result));
    }


}

/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Sends Approve IT requests
 */
package services;
import globalfunctions.Global;
import globalfunctions.ReadCSV;
import objectTemplate.objectTemplate;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;
import static org.hamcrest.Matchers.is;

public class ApproveITTests extends Global {
    private Response response;
    private int verificationID;
    private  objectTemplate approveITObjects;
    private  Global globalvariables;
    private  GetRecordAPITests getRecord;
    private ReadCSV readcsv;
    public  ApproveITTests()
    {
        globalvariables = new Global();
        approveITObjects =  new objectTemplate();
        getRecord = new GetRecordAPITests();
        readcsv = new ReadCSV();
        if(globalvariables.port != 0) {
            SerenityRest.proxy(globalvariables.proxy, globalvariables.port);
        }
        //datapower goes through a different proxy and port defined in the pom file
    }

    @Step
    public void sendSellerApproveITRequest(String verifyuri, String identityNumber, String cellphone,String firstName,
                                     String lastName,
                                     String verificationId, String otp,
                                     String reference,String type){

        getRecord.callGetApplication();
        response = SerenityRest.
                given().relaxedHTTPSValidation()
                .body(approveITObjects.SellerApproveITDetails(globalvariables.sellerwhoami,cellphone,firstName,lastName
                        ,verificationId,otp,getRecord.getFoxRef(),type).toString()).
                contentType("application/json")
                .header("Authorization", "Bearer "+ globalvariables.jwtToken)
                .when()
                .post(globalvariables.approveITUrl + verifyuri);
    }
    @Step
    public void sendBuyerApproveITRequest(String verifyuri, String identityNumber, String cellphone,
                                          String firstName,
                                          String lastName,String verificationId, String otp,
                                     String reference,String type){
        //SerenityRest.proxy("172.17.2.12 ", 80);
        //getRecord.callGetApplication();
        response = SerenityRest.
                given().relaxedHTTPSValidation()
                .body(approveITObjects.ApproveITDetails(globalvariables.whoami,cellphone,
                        firstName,lastName,verificationId,otp,"",type).toString()).
                        contentType("application/json").
                        header("Authorization", "Bearer "+ globalvariables.jwtToken)
                .when()
                .post(globalvariables.approveITUrl + verifyuri);
    }

    @Step
    public void getToken(String fileName)
    {
        readcsv.WriteToCSV(fileName, response.then().extract().path("data.token"));
    }

    @Step
    public  void validateInitiateResponse()
    {
        response.then()
                .body("metaData.name", is("Success"));
    }

}
/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Vehicle Offer Step Definition
 */
package stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;


public class VehicleOfferDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;

    public VehicleOfferDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();

    }

    @Given("^that I have a set of  vehicle offer details \"([^\"]*)\"$")
    public void that_I_have_a_set_of_vehicle_offer_details(String arg1) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        getRecordTest.callGetAPISeller("SellerVehicle");
    }

    @Then("^the retrieving of vehicle offer details result should return  \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void the_retrieving_of_vehicle_offer_details_result_should_return_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
    getRecordTest.validateResponse("Success");
    }

    @Given("^that I have a set of vehicle offer details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" \"([^\"]*)\"and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_vehicle_offer_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        getRecordTest.callGetAPISeller("SellerVehicle");
    }

    @When("^I submit vehicle offer details  to the system$")
    public void i_submit_vehicle_offer_details_to_the_system() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
    }

    @Then("^the vehicle offer details  result should return \"([^\"]*)\"$")
    public void the_vehicle_offer_details_result_should_return(String arg1) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        getRecordTest.validateResponse("Success");
    }
}

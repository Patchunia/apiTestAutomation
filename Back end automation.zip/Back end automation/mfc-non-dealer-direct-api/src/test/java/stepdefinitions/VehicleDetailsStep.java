/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Vehicle Details Step Definition
 */
package stepdefinitions;

import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class VehicleDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    Global globalfunctions;
    List<String[]> lines;
    ReadCSV test;
    public VehicleDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        globalfunctions = new Global();
        test = new ReadCSV();
        lines = test.callCSV("VehicleDetailsData.csv");
    }
    public void SaveVehicleDetails()
    {
        int applicationID = globalfunctions.applicationID;
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            //System.out.println(lineContents[0]);
            createRecordTest.saveVehicleDetails(globalfunctions.GetDashID(),Integer.parseInt(lineContents[0]),
                    lineContents[1],
                    lineContents[2],lineContents[3],lineContents[4],
                    Boolean.parseBoolean(lineContents[5]),lineContents[6],lineContents[7],lineContents[8],Integer.parseInt(lineContents[9]),
                    Integer.parseInt(lineContents[10]),Integer.parseInt(lineContents[11]),Boolean.parseBoolean(lineContents[12])
                    ,Integer.parseInt(lineContents[13]),Integer.parseInt(lineContents[14]),
                    Boolean.parseBoolean(lineContents[15]),Integer.parseInt(lineContents[16]),lineContents[17],
                    Integer.parseInt(lineContents[18]), Integer.parseInt(lineContents[19]),lineContents[20],
                    lineContents[21],Boolean.parseBoolean(lineContents[22]));
        }
    }
    @Given("^that I have a set of dealer vehicle details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\"\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_dealer_vehicle_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12, String arg13, String arg14, String arg15, String arg16, String arg17, String arg18, String arg19, String arg20, String arg21, String arg22, String arg23, String arg24) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SaveVehicleDetails();
    }

    @Given("^that I have a set of changed dealer vehicle details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\"\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_dealer_vehicle_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12, String arg13, String arg14, String arg15, String arg16, String arg17, String arg18, String arg19, String arg20, String arg21, String arg22, String arg23, String arg24) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SaveVehicleDetails();
    }

    @Then("^the capturing of dealer vehicle details result should return \"([^\"]*)\"$")
    public void the_capturing_of_dealer_vehicle_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response("Success");
    }

    @Then("^the updating of dealer vehicle details result should return \"([^\"]*)\"$")
    public void the_updating_of_dealer_vehicle_details_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response("Success");
    }



    @When("^I submit dealer vehicle details to the system$")
    public void i_submit_dealer_vehicle_details_to_the_system()  {
        // Write code here that turns the phrase above into concrete actions

    }


}

/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Personal Income Step Definition
 */

package stepdefinitions;

import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class PersonallIncomeDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    Global globalfunctions;
    ReadCSV test;
    List<String[]> lines;
    public PersonallIncomeDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        globalfunctions = new Global();
        test = new ReadCSV();
        lines = test.callCSV("PersonalIncomeDetailsData.csv");

    }
    public void SavePersonalIncome()
    {
        int applicationID = globalfunctions.applicationID;
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            createRecordTest.savePersonalIncome(globalfunctions.GetDashID(),Integer.parseInt(lineContents[0]),
                    Integer.parseInt(lineContents[1]),Integer.parseInt(lineContents[2]));
        }
    }
    @Given("^that I have a set of personal income details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_personal_income_details_and(String arg1, String arg2, String arg3, String arg4) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SavePersonalIncome();
    }

    @Given("^that I have a set of changed personal income details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_personal_income_details_and(String arg1, String arg2, String arg3, String arg4) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SavePersonalIncome();
    }
    @When("^I submit personal income details to the system$")
    public void i_submit_personal_income_details_to_the_system(){
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^the capturing of personal income details result should return \"([^\"]*)\"$")
    public void the_capturing_of_personal_income_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response("Success");
    }



}

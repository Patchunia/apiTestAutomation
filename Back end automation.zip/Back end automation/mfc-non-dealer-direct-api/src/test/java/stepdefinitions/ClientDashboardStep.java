/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Client Dashboard Step Definition
 */
package stepdefinitions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

public class ClientDashboardStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;

    public ClientDashboardStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();

    }
    @Given("^that I have an existing \"([^\"]*)\" on the system$")
    public void that_I_have_an_existing_on_the_system(String IDNumber) {
        // Write code here that turns the phrase above into concrete actions
        //getRecordTest.callGetDashboardAPI(IDNumber, "dashboard");
    }


    @When("^I submit the existing detail to the system$")
    public void i_submit_the_existing_detail_to_the_system() {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^view these correct set of details for  \"([^\"]*)\"$")
    public void view_these_correct_set_of_details_for(String IdentityNumber) {
        // Write code here that turns the phrase above into concrete actions
        //getRecordTest.validateApplicationsIDNumber(IdentityNumber);
    }



}

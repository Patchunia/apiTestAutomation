/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Accept Consent Step Definition
 */

package stepdefinitions;
import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class AcceptConsentStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    List<String[]> lines;
    ReadCSV test;
    Global globalfunctions;
    public AcceptConsentStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        test = new ReadCSV();
        lines = test.callCSV("AcceptConsentDetailsData.csv");
        globalfunctions= new Global();
    }

    public void SaveAcceptConsentDetails()
    {

        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            createRecordTest.saveAcceptConsentDetails(lineContents[0],
                    lineContents[1],
                    lineContents[2],lineContents[3], lineContents[4],
                    lineContents[5],lineContents[6],lineContents[7],
                    lineContents[8],lineContents[9],lineContents[10],lineContents[11]
                    , Boolean.parseBoolean(lineContents[12]),Boolean.parseBoolean(lineContents[13]),
                    Boolean.parseBoolean(lineContents[14]),Boolean.parseBoolean(lineContents[15]),
                    Boolean.parseBoolean(lineContents[16]),Boolean.parseBoolean(lineContents[17]),Boolean.parseBoolean(lineContents[18]));
        }
    }
    @Given("^user sends qualifying criteria details \"([^\"]*)\",\"([^\"]*)\"\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_sends_qualifying_criteria_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        SaveAcceptConsentDetails();
    }

    @Then("^sending qualifying criteria details should return \"([^\"]*)\"$")
    public void sending_qualifying_criteria_details_should_return(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response("Success");
        createRecordTest.saveDashboardID();

    }


}

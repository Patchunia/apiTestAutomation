/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Cancel Application Step Definition
 */
package stepdefinitions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import services.DeleteRecordAPITests;


public class CancelApplicationStep {

    DeleteRecordAPITests deleteRecordTest;
    public CancelApplicationStep()
    {
        deleteRecordTest = new DeleteRecordAPITests();
    }

    @Given("^that I have a set of cancel application details \"([^\"]*)\"$")
    public void that_I_have_a_set_of_cancel_application_details(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        deleteRecordTest.callDeleteApplication();
    }


    @Then("^the cancelling of application details details result should return \"([^\"]*)\"$")
    public void the_cancelling_of_application_details_details_result_should_return(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        deleteRecordTest.validateResponse("Success");
    }



}

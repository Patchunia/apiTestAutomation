/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Employment Details Step Definition
 */
package stepdefinitions;

import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class EmploymentDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    ReadCSV test;
    List<String[]> lines;
    Global globalfunctions;
    public EmploymentDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        test = new ReadCSV();
        lines = test.callCSV("EmploymentDetailsData.csv");
        globalfunctions = new Global();
    }
    public void SaveEmploymentDetails()
    {
        int applicationID = globalfunctions.dashboardID;
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            //System.out.println(lineContents[0]);
            createRecordTest.saveEmploymentdetails(globalfunctions.GetDashID(),Integer.parseInt(lineContents[0]),lineContents[0],lineContents[0],lineContents[0],lineContents[0],
                    lineContents[0],lineContents[0],lineContents[0],lineContents[0]);
        }


    }

    @When("^I submit employment details to the system$")
    public void i_submit_employment_details_to_the_system() {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^the capturing of employment details result should return \"([^\"]*)\"$")
    public void the_capturing_of_employment_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response(result);
    }
    @Given("^that I have a set of employment details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_employment_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SaveEmploymentDetails();
    }


    @Given("^that I have a set of changed employment details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_employment_details_and(int IdentityNumber, String TypeOfEmployment, String Occupation, String CurrentEmployer,
                                                                    String Industry, String CurrentEmployerWorkingDate) {

        SaveEmploymentDetails();
    }

    @Then("^the updating of employment details result should return \"([^\"]*)\"$")
    public void the_updating_of_employment_details_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(result);
    }
    @Then("^\"([^\"]*)\",\"([^\"]*)\" ,\"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\" and \"([^\"]*)\" must be correctly captured$")
    public void and_must_be_correctly_captured(int IdentityNumber, String TypeOfEmployment, String Occupation, String CurrentEmployer,
                                               String Industry, String CurrentEmployerWorkingDate)  {
        // Write code here that turns the phrase above into concrete actions
       //getRecordTest.validateEmploymentDetails(IdentityNumber,TypeOfEmployment,Occupation,CurrentEmployer,
          //     Industry,CurrentEmployerWorkingDate);
    }


    @When("^when I validate that the employment details were updated I send \"([^\"]*)\"$")
    public void when_I_validate_that_the_employment_details_were_updated_I_send(String IdentityNumber)  {
        // Write code here that turns the phrase above into concrete actions
        //getRecordTest.callGetRecordAPI(IdentityNumber, "employmentdetails ");
    }
    @Then("^\"([^\"]*)\",\"([^\"]*)\" ,\"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\" and \"([^\"]*)\" must be correctly updated$")
    public void and_must_be_correctly_updated(int IdentityNumber, String TypeOfEmployment, String Occupation, String CurrentEmployer,
                                              String Industry, String CurrentEmployerWorkingDate)  {
        // Write code here that turns the phrase above into concrete actions
        //getRecordTest.validateEmploymentDetails(IdentityNumber,TypeOfEmployment,Occupation,CurrentEmployer,
          //      Industry,CurrentEmployerWorkingDate);
    }

}

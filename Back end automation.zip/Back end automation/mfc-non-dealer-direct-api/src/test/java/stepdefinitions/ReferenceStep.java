/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: References Step Definition
 */

package stepdefinitions;

import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import services.ReferenceAPITests;

public class ReferenceStep {

    ReferenceAPITests dropdownTest;
    ReadCSV readCSV;
    public ReferenceStep()
    {
        dropdownTest  =  new ReferenceAPITests();
        readCSV =  new ReadCSV();
    }
    @Given("^user sends \"([^\"]*)\" path$")
    public  void sendURI(String URI)
    {
        dropdownTest.sendGetRequest(URI);
    }
    @Given("^user sends country details \"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_sends_country_details_and(String country, String excludedCountry) {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        dropdownTest.sendGetRequest("countries/" + country + "/" + excludedCountry);
    }

    @Then("^user views the dropdown data$")
    public void validateData() {

        dropdownTest.validateDropDown("Success");
    }
    @Given("^user sends dealer type details \"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_sends_dealer_type_details_and(String dealerType, String dashboardID) {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.GetDealerType(dashboardID, dealerType);
    }

    @Then("^user views the correct  \"([^\"]*)\" dealer type details$")
    public void user_views_the_correct_dealer_type_details(boolean dealerTypeUpdate) {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.validateDealerType(dealerTypeUpdate);
    }


    @Given("^user sends location details \"([^\"]*)\"$")
    public void user_sends_location_details(String suburb)  {
        // Write code here that turns the phrase above into concrete actions
       dropdownTest.sendGetRequest("suburbs/" + suburb);
    }

    @Given("^user sends user sends dealersbyregion details \"([^\"]*)\"$")
    public void user_sends_user_sends_dealersbyregion_details(String city)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.sendDealerGetRequest("region/" + city + "?region= "  + city);
    }

    @Then("^user views dealersbyregion$")
    public void user_views_dealersbyregion()  {
        // Write code here that turns the phrase above into concrete actions
            dropdownTest.validateDropDown("Success");
    }

    @Given("^user sends user sends citiesbyregions details \"([^\"]*)\"$")
    public void user_sends_user_sends_citiesbyregions_details(String city) {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.sendDealerGetRequest("region/" + city + "?region= "  + city);
    }

    @Given("^user sends vehicle make and model \"([^\"]*)\"  and \"([^\"]*)\"$")
    public void user_sends_vehicle_make_and_model_and(String type, String year)  {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        dropdownTest.sendVehicleGetRequest("makes/" + type + "/" + year);
    }

    @Given("^user sends vehicle make by type \"([^\"]*)\" , \"([^\"]*)\"  and \"([^\"]*)\"$")
    public void user_sends_vehicle_make_by_type_and(String type, String year, String make)  {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        dropdownTest.sendVehicleGetRequest("models/" + type + "/" + year + "/" + make);
    }
    @Then("^user views citiesbyregions$")
    public void user_views_citiesbyregions()  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.validateDropDown("Success");
    }

    @Given("^user sends dealersbycity details  \"([^\"]*)\"$")
    public void user_sends_dealersbycity_details(String city)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.sendDealerGetRequest("name/" + city);
    }

    @Then("^user views dealersbycity$")
    public void user_views_dealersbycity()  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.validateDropDown("Success");
    }


    @Then("^user views suburb \"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_views_suburb_and(String postalCode, String city)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.ValidateSuburbResponse(postalCode,city);
    }

    @Then("^user views \"([^\"]*)\" by region$")
    public void user_views_by_region(String City)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownTest.shouldGetData();
    }
}

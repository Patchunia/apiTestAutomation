/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Search for Dealer Step Definition
 */
package stepdefinitions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import services.ReferenceAPITests;

public class SearchForDealerStep {


    ReferenceAPITests dropdownList;
    public SearchForDealerStep()
    {
        dropdownList = new ReferenceAPITests();
    }
    @Given("^that I have a set of dealer location details \"([^\"]*)\"$")
    public void that_I_have_a_set_of_dealer_location_details(String dealerName)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownList.GetDealer(dealerName);
    }

    @When("^I submit location details to the system$")
    public void i_submit_location_details_to_the_system()  {
        // Write code here that turns the p.hrase above into concrete actions

    }

    @Then("^the capturing of dealer details result should return \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void the_capturing_of_dealer_details_result_should_return_and(String dealerName, String dealerCode, String city, String suburb)  {
        // Write code here that turns the phrase above into concrete actions
        dropdownList.ValidateDealerResponse(dealerName,dealerCode,city,suburb);
    }

}

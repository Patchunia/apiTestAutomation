/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Seller Vehicle Details Step Definition
 */
package stepdefinitions;

import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class SellerVehicleDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    Global globalfunctions;
    List<String[]> lines;
    ReadCSV test;
    public SellerVehicleDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        globalfunctions = new Global();
        test = new ReadCSV();
        //lines = test.callCSV("VehicleDetailsData.csv");
    }
    @Given("^that I have a set of seller vehicle details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_seller_vehicle_details_and(String arg1, String vin, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveSellerVehicleDetails(globalfunctions.GetDashID(),0,"","",
                "","",true,"","","",2018,200,500,
                false,12,345,true,1253, "",
                7,8,vin, "",false);
    }

    @When("^I submit seller vehicle details to the system$")
    public void i_submit_seller_vehicle_details_to_the_system()  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.saveSellerVehicleResult(globalfunctions.GetDashID());
    }

    @Then("^the capturing of seller vehicle details result should return \"([^\"]*)\"$")
    public void the_capturing_of_seller_vehicle_details_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response("Success");
    }

}

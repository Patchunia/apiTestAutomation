/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Application States Step Definition
 */

package stepdefinitions;

import globalfunctions.Global;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import services.GetRecordAPITests;

public class ApplicationStatesStep {


    GetRecordAPITests getRecordTest;
    Global globalfunctions;
    public ApplicationStatesStep()
    {

        getRecordTest = new GetRecordAPITests();
        globalfunctions= new Global();
    }

    @Given("^user sends application states \"([^\"]*)\" path$")
    public void user_sends_application_states_path(String StateURI)  {
        // Write code here that turns the phrase above into concrete actions
            getRecordTest.callGetAPI(StateURI);
    }

    @Then("^user views the application information$")
    public void user_views_the_application_information() {
        // Write code here that turns the phrase above into concrete actions
        getRecordTest.validateResponse("Success");
    }

    @Given("^user sends seller application states \"([^\"]*)\" path$")
    public void user_sends_seller_application_states_path(String StateURI)  {
        // Write code here that turns the phrase above into concrete actions
        getRecordTest.callGetAPISeller(StateURI);
    }

    @Then("^user views the seller state application information$")
    public void user_views_the_seller_state_application_information()  {
        // Write code here that turns the phrase above into concrete actions
        getRecordTest.validateResponse("Success");
    }


}

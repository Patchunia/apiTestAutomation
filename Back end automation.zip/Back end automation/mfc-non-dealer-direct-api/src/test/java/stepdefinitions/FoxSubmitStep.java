/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Fox Submit Step Definition
 */
package stepdefinitions;

import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class FoxSubmitStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    Global global_functions;
    List<String[]> lines;
    ReadCSV test;
    Global globalfunctions;
    public FoxSubmitStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        global_functions = new Global();
        test = new ReadCSV();
        globalfunctions= new Global();
    }
    @Given("^that I have a set of submission details \"([^\"]*)\"$")
    public void that_I_have_a_set_of_submission_details(String ApplicationID) {
        // Write code here that turns the phrase above into concrete actions
        int AppID = Integer.parseInt(ApplicationID);
       createRecordTest.saveFoxSecondSubmit(globalfunctions.GetDashID());
    }

    @When("^I submit submission details to the system$")
    public void i_submit_submission_details_to_the_system(){
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^the submission result should return \"([^\"]*)\"$")
    public void the_submission_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response("Success");
    }

}

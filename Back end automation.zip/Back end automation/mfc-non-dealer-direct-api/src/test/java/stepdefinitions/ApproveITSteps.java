/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: ApproveIT Step Definitions
 */
package stepdefinitions;
import globalfunctions.Global;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import services.ApproveITTests;
import services.GetRecordAPITests;

public class ApproveITSteps {

    ApproveITTests approveITTests ;
    Global globalFunctions;
    GetRecordAPITests   getRecordTest;

    public ApproveITSteps() {

        approveITTests = new ApproveITTests();
        globalFunctions = new Global();
        getRecordTest = new GetRecordAPITests();
    }


    @Given("^seller sends \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" to InitiateOTP$")
    public void seller_sends_and_to_InitiateOTP(String identityNumber, String cellphone, String firstName, String lastName,
                                                String verificationId, String otp, String reference, String type) {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendSellerApproveITRequest("otp",
                globalFunctions.sellerwhoami,cellphone,firstName,lastName,verificationId,otp,reference,type);
    }


    @Given("^seller sends \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" to InitiateUSSD$")
    public void seller_sends_and_to_InitiateUSSD(String identityNumber, String cellphone, String firstName, String lastName,
                                                 String verificationId, String otp, String reference, String type)  {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendSellerApproveITRequest("ussd",
                globalFunctions.sellerwhoami,cellphone,firstName,lastName,verificationId,otp,reference,type);
        approveITTests.getToken("SellerSessionToken.csv");
    }

    @Given("^seller sends \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" to InitiateOTP Verification$")
    public void seller_sends_and_to_InitiateOTP_Verification(String identityNumber, String cellphone, String firstName, String lastName,
                                                             String verificationId, String otp, String reference, String type) {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendSellerApproveITRequest("otpverifications",
                globalFunctions.sellerwhoami,cellphone,firstName,lastName,verificationId,otp,reference,type);
    }


    @Given("^user sends \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" to InitiateUSSD$")
    public void user_sends_and_to_InitiateUSSD(String identityNumber, String cellphone,String firstName,
                                               String lastName,
                                               String verificationId, String otp,
                                               String reference,String type) {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendBuyerApproveITRequest("ussd",globalFunctions.whoami,cellphone,firstName,lastName,
                verificationId,otp,reference,type);
        approveITTests.getToken("SessionToken.csv");
    }

    @Given("^user sends \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" to InitiateOTP Verification$")
    public void user_sends_and_to_InitiateOTP_Verification(String identityNumber, String cellphone,String firstName,
                                                           String lastName,
                                                           String verificationId, String otp,
                                                           String reference,String type)  {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendBuyerApproveITRequest("otpverifications",globalFunctions.whoami,cellphone,firstName,lastName,
                verificationId,otp,reference,type);
    }
    @Given("^user sends \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" to InitiateOTP$")
    public void user_sends_and_to_InitiateOTP(String identityNumber, String cellphone,String firstName,
                                              String lastName,
                                              String verificationId, String otp,
                                              String reference,String type)  {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendBuyerApproveITRequest("otp",globalFunctions.whoami,cellphone,firstName,lastName,
                verificationId,otp,reference,type);
    }

    @Given("^user sends \"([^\"]*)\" to view identity result$")
    public void user_sends_to_view_identity_result(String IdentityNumber) {
        // Write code here that turns the phrase above into concrete actions
     getRecordTest.callGetClientApplication();
    }

    @Then("^sending of identity number for identity should return \"([^\"]*)\"$")
    public void sending_of_identity_number_for_identity_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
        getRecordTest.validateResponse("Success");
    }

    @Then("^sending of OTP should return \"([^\"]*)\"$")
    public void sending_of_OTP_should_return(String arg1) {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.validateInitiateResponse();

    }



    @Then("^sending of USSD should return \"([^\"]*)\"$")
    public void sending_of_USSD_should_return(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();

        approveITTests.validateInitiateResponse();
    }


    @Then("^sending of initiate OTP should return \"([^\"]*)\"$")
    public void sending_of_initiate_OTP_should_return(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        //approveITTests.getToken();
        approveITTests.validateInitiateResponse();
    }


}
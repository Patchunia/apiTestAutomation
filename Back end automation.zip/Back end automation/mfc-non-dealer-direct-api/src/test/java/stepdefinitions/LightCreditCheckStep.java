/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Fox Light Credit Check Step Definition
 */
package stepdefinitions;
import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import services.ApproveITTests;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class LightCreditCheckStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    List<String[]> lines;
    ReadCSV test;
    Global globalfunctions;
    ApproveITTests approveITTests ;
    public LightCreditCheckStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        test = new ReadCSV();
        globalfunctions= new Global();
        approveITTests = new ApproveITTests();
    }

    @Given("^buyer sends \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\" for a Light Bureau Enquiry$")
    public void buyer_sends_and_for_a_Light_Bureau_Enquiry(String IdentityNumber, String FirstName, String Surname, String CellphoneNumber)  {
        // Write code here that turns the phrase above into concrete actions
        approveITTests.sendBuyerApproveITRequest("ussd",globalfunctions.whoami,CellphoneNumber,FirstName,Surname,
               "","","","Buyer");
    }


    @Then("^the sending of Light Bureau Enquiry should return \"([^\"]*)\"$")
    public void the_sending_of_Light_Bureau_Enquiry_should_return(String Result)  {
        // Write code here that turns the phrase above into concrete actions
            approveITTests.validateInitiateResponse();
    }


}

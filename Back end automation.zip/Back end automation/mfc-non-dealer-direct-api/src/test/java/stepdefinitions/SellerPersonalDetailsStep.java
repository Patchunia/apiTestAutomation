/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Seller Personal Details Step Definition
 */
package stepdefinitions;
import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class SellerPersonalDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    Global globalfunctions;
    List<String[]> lines;
    ReadCSV test;

    public SellerPersonalDetailsStep()
    {
        test = new ReadCSV();
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        lines = test.callCSV("SellerPersonalDetailsData.csv");
        globalfunctions= new Global();

    }

    public void SaveSellerPersonalDetails()
    {
        int applicationID = globalfunctions.applicationID;
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            //System.out.println(lineContents[0]);
            createRecordTest.saveSellerPersonalDetails(globalfunctions.GetDashID(), globalfunctions.whoami, lineContents[1], lineContents[2], globalfunctions.sellerCellphone,
                    lineContents[4], lineContents[5], lineContents[6], lineContents[7], lineContents[8],
                    lineContents[9], lineContents[10]);
        }
    }

    @Given("^that I have a set of seller personal details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_seller_personal_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11)  {
        // Write code here that turns the phrase above into concrete actions
       SaveSellerPersonalDetails();
    }


    @When("^I submit seller personal details to the system$")
    public void i_submit_seller_personal_details_to_the_system() throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
    }

    @Then("^the capturing of seller personal details result should return \"([^\"]*)\"$")
    public void the_capturing_of_seller_personal_details_result_should_return(String arg1) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        createRecordTest.shouldGet200Response("Success");
    }

}

/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Seller Details Step Definition
 */
package stepdefinitions;

import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class SellerDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    List<String[]> lines;
    ReadCSV test;
    Global globalfunctions;
    public SellerDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        test = new ReadCSV();
        lines = test.callCSV("SellerContactDetails.csv");
        globalfunctions= new Global();
    }
    public void SaveSellerContactDetails()
    {
        //int applicationID = globalfunctions.applicationID;
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            //System.out.println(lineContents[0]);
            createRecordTest.saveSellerContact(globalfunctions.GetDashID(),globalfunctions.sellerwhoami,
                    lineContents[1],
                    lineContents[2],lineContents[3].trim(),lineContents[4],
                    lineContents[5],lineContents[6],lineContents[7],lineContents[8],lineContents[9],lineContents[10]);
        }
    }
    @Given("^that I have a set of seller details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"test\"([^\"]*)\"test\"$")
    public void that_I_have_a_set_of_seller_details_test_test(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SaveSellerContactDetails();

    }

    @Given("^that I have a set of  changed seller details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"test\"([^\"]*)\"test\"$")
    public void that_I_have_a_set_of_changed_seller_details_test_test(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SaveSellerContactDetails();
    }
    @When("^I submit seller details to the system$")
    public void i_submit_seller_details_to_the_system()  {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^the capturing of seller details result should return \"([^\"]*)\"$")
    public void the_capturing_of_seller_details_result_should_return(String result){
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response("Success");
    }

    @Then("^the updating of seller details result should return \"([^\"]*)\"$")
    public void the_updating_of_seller_details_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response("Success");
    }
}

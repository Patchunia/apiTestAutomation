/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Banking Details Step Definition
 */
package stepdefinitions;
import globalfunctions.ReadCSV;
import globalfunctions.Global;
import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;

public class BankingDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    List<String[]> lines;
    ReadCSV test;
    Global globalfunctions;
    public BankingDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        test = new ReadCSV();
        globalfunctions= new Global();
    }

    public void SaveBankingDetails()
    {
        //int applicationID = globalfunctions.dashboardID;
        lines = test.callCSV("BankingDetailsData.csv");
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            //System.out.println(lineContents[0]);
            createRecordTest.saveBankingDetails(globalfunctions.GetDashID(),Integer.parseInt(lineContents[0].trim().toString()),
                    lineContents[1],
                    lineContents[2],Integer.parseInt(lineContents[3].trim().toString()),lineContents[4],
                    lineContents[5],lineContents[6],lineContents[7]);
        }
    }

   public  String  returnResponse()
   {
       String response = "";
       try {
           for (int i = 0; i < lines.size(); i++) {
               String[] lineContents = lines.get(i);
               response = lineContents[8];
           }
       }
       catch (Exception e)
       {
           response = e.getMessage();
       }
       return  response;
   }

    @When("^I submit banking details to the system$")
    public void i_submit_banking_details_to_the_system()  {
        //DataDriveWriteToCSV();
        //createRecordTest.saveResponse();
    }

    @Then("^the updating of banking details result should return \"([^\"]*)\"$")
    public void the_personal_details_for_that_individual_are_successfully_added(String Result)  {
        createRecordTest.shouldGet200Response(returnResponse().toString());
    }
    @Then("^the capturing of banking details result should return \"([^\"]*)\"$")
    public void the_personal_details_for_that_individual_are_successfully_updated(String Result)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response(returnResponse().toString());

    }

    @Given("^that I have a set of banking details \"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_banking_details_and(int ApplicationID,
                                                         int BankID ,String BankCode, String BankName,
                                                         int AccountTypeId,String AccountTypeCode,String AccountTypeName,
                                                         String AccountNumber,String BranchCode) {
        // Write code here that turns the phrase above into concrete actions

        SaveBankingDetails();

    }

    @Given("^that I have a set of changed bank details \"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_bank_details_and(int AppilicationID,
                                                              int BankID ,String BankCode, String BankName,
                                                              int AccountTypeId,String AccountTypeCode,String AccountTypeName,
                                                              String AccountNumber,String BranchCode) {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SaveBankingDetails();
    }
    @When("^when I validate that the banking details were updated I send \"([^\"]*)\"$")
        public void when_I_validate_that_the_banking_details_were_updated_I_send(String IDNumber)  {
            // Write code here that turns the phrase above into concrete actions
            //getRecordTest.callGetRecordAPI(IDNumber, "bankingdetails");
        }
    @Given("^that I have a set of view bank details \"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_view_bank_details_and(String arg1, String arg2)  {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
    }

    @Then("^the viewing of banking details result should return \"([^\"]*)\"$")
    public void the_viewing_of_banking_details_result_should_return(String arg1) {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
    }

}

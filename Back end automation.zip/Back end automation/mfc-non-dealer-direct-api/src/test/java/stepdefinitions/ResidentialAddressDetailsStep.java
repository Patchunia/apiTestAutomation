/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class: Residential Address Details Step Definition
 */
package stepdefinitions;

import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class ResidentialAddressDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    Global globalfunctions;
    List<String[]> lines;
    ReadCSV test;
    public ResidentialAddressDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        globalfunctions = new Global();
        test = new ReadCSV();
        lines = test.callCSV("ResidentialAddressDetailsData.csv");

    }
    public void SaveResidentialAddressDetails()
    {

        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            createRecordTest.saveResidentialAddress(globalfunctions.GetDashID(),Integer.parseInt(lineContents[0]),
                    lineContents[1],
                    lineContents[2],lineContents[3],lineContents[4],
                    lineContents[5],lineContents[6],lineContents[7],lineContents[8],Boolean.parseBoolean(lineContents[9]),
                    lineContents[10],lineContents[11],lineContents[12],lineContents[13],lineContents[14]
                    );
        }
    }
    @Given("^that I have a set of residential address details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_residential_address_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12, String arg13, String arg14, String arg15, String arg16) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SaveResidentialAddressDetails();
    }

    @Given("^that I have a set of changed residential address details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_residential_address_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12, String arg13, String arg14, String arg15, String arg16) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SaveResidentialAddressDetails();
    }
    @When("^I submit residential address details to the system$")
    public void i_submit_residential_address_details_to_the_system() {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^the capturing of residential address details result should return \"([^\"]*)\"$")
    public void the_capturing_of_residential_address_details_result_should_return(String result) {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response(result);
    }

    @Then("^the updating of residential address details result should return \"([^\"]*)\"$")
    public void the_updating_of_residential_address_details_result_should_return(String result)  {
        // Write code here that turns the phrase above into concrete actions
            createRecordTest.shouldGet200Response(result);
    }

}

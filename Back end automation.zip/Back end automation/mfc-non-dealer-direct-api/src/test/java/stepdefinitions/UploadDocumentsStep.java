/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Upload Documents Step Definition
 */
package stepdefinitions;

import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class UploadDocumentsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    List<String[]> lines;
    ReadCSV test;
    Global globalfunctions;
    public UploadDocumentsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        test = new ReadCSV();
        lines = test.callCSV("UploadDocDetailsData.csv");
        globalfunctions= new Global();
    }
    public void SaveBuyerUploadDocumentDetails()
    {
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            createRecordTest.saveBuyerDocuments(globalfunctions.GetDashID(),Integer.parseInt(lineContents[0]),
                    lineContents[1],lineContents[2],lineContents[3],lineContents[4],Integer.parseInt(lineContents[5]),
                    lineContents[7]);
        }
    }
    public void SaveSellerUploadDocumentDetails()
    {

        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            //System.out.println(lineContents[0]);
            createRecordTest.saveSellerDocuments(globalfunctions.GetDashID(),Integer.parseInt(lineContents[0]),
                    lineContents[1],lineContents[2],lineContents[3],lineContents[4],Integer.parseInt(lineContents[5]),
                    lineContents[6]);
        }
    }
    //This method reads data contents from csv

    @Given("^buyer sends documents \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and\"([^\"]*)\"  for document upload$")
    public void buyer_sends_documents_and_for_document_upload(int ApplicationID,int documentTypeId,String documentTypeCode,String documentTypeName
            ,String fileFormat,String fileName,int fileSize,String fileContent)  {
        // Write code here that turns the phrase above into concrete actions
        SaveBuyerUploadDocumentDetails();
    }


    @Given("^seller sends documents \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and\"([^\"]*)\"  for document upload$")
    public void seller_sends_documents_and_for_document_upload(int ApplicationID,int documentTypeId,String documentTypeCode,String documentTypeName
            ,String fileFormat,String fileName,int fileSize,String fileContent) {
        // Write code here that turns the phrase above into concrete actions

       SaveSellerUploadDocumentDetails();
    }


    @Then("^the sending of documents should return \"([^\"]*)\"$")
    public void the_sending_of_documents_should_return(String arg1)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response("Success");

    }




}

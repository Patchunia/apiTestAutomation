/*
Project:MFC Non Dealer Direct
Author: Miss P
Purpose of Class:Personal Income Step Definition
 */

package stepdefinitions;
import globalfunctions.Global;
import globalfunctions.ReadCSV;
import cucumber.api.java.en.Given;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import services.CreateRecordAPITests;
import services.GetRecordAPITests;

import java.util.List;


public class PersonalDetailsStep {

    CreateRecordAPITests createRecordTest ;
    GetRecordAPITests getRecordTest;
    Global globalfunctions;
    List<String[]> lines;
    ReadCSV test;
    public PersonalDetailsStep()
    {
        createRecordTest = new CreateRecordAPITests();
        getRecordTest = new GetRecordAPITests();
        globalfunctions = new Global();
        test = new ReadCSV();
        lines = test.callCSV("PersonalDetailsData.csv");
    }
    public void SavePersonalDetails()
    {
        int applicationID = globalfunctions.applicationID;
        for (int i = 0; i < lines.size(); i++) {
            String[] lineContents = lines.get(i);
            //System.out.println(lineContents[0]);
            createRecordTest.savePersonalDetails(globalfunctions.GetDashID(),Integer.parseInt(lineContents[0]),
                    lineContents[1],
                    lineContents[2],Integer.parseInt(lineContents[3]),lineContents[4],
                    lineContents[5],Integer.parseInt(lineContents[6]),lineContents[7],lineContents[8],Integer.parseInt(lineContents[9]),
                    lineContents[10],lineContents[11],Integer.parseInt(lineContents[12]),lineContents[13],lineContents[14],
                    lineContents[15],lineContents[16],lineContents[17],lineContents[18],lineContents[19],lineContents[20],
                    lineContents[21],lineContents[22],Boolean.parseBoolean(lineContents[23]),Boolean.parseBoolean(lineContents[24]));
        }
    }
    @When("^I submit personal details to the system$")
    public void i_submit_personal_details_to_the_system() {
        // Write code here that turns the phrase above into concrete actions

    }



    @Given("^that I have a set of personal details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_personal_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12, String arg13, String arg14, String arg15, String arg16, String arg17, String arg18, String arg19, String arg20, String arg21, String arg22, String arg23, String arg24, String arg25, String arg26) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SavePersonalDetails();
    }


    @Given("^that I have a set of changed personal details \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void that_I_have_a_set_of_changed_personal_details_and(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12, String arg13, String arg14, String arg15, String arg16, String arg17, String arg18, String arg19, String arg20, String arg21, String arg22, String arg23, String arg24, String arg25, String arg26) throws Exception {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        SavePersonalDetails();
    }


    @Then("^the capturing of personal details result should return \"([^\"]*)\"$")
    public void the_personal_details_for_that_individual_are_successful_captured(String compareString)  {
        // Write code here that turns the phrase above into concrete actions
        createRecordTest.shouldGet200Response("Success");
    }

    @Then("^the updating of personal details result should return \"([^\"]*)\"$")
    public void the_personal_details_for_that_individual_are_successful_updated(String compareString)  {
        createRecordTest.shouldGet200Response("Success");
    }



}
